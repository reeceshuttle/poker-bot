from skeleton.actions import FoldAction, CallAction, CheckAction, RaiseAction
from skeleton.states import GameState, TerminalState, RoundState
from skeleton.states import NUM_ROUNDS, STARTING_STACK, BIG_BLIND, SMALL_BLIND
from skeleton.bot import Bot
from skeleton.runner import parse_args, run_bot

import eval7
import random


def ParseHoleCards(hole_cards):
    """
    hole_cards will look like this: ["Ac", "Ts"]
    """
    # dealing with suits
    if hole_cards[0][1] == hole_cards[1][1]: # suited
        last = 's'
    else: # unsuited
        last = 'u'

    # dealing with card ranks
    ranks = ["2", "3", "4", "5", "6", "7", "8", "9", "T", "J", "Q", "K", "A"]
    if ranks.index(hole_cards[0][0]) >= ranks.index(hole_cards[1][0]):
        first = f"{hole_cards[0][0]}{hole_cards[1][0]}"
    else:
        first = f"{hole_cards[1][0]}{hole_cards[0][0]}"
    return first + last


def EvalBoard(game_state, round_state, active):
    """
    evaluates board. Returns string saying what the board has. 
    """
    street = round_state.street  # int representing pre-flop, flop, turn, or river respectively
    board_cards = round_state.deck[:street]  # the board cards
    hand = [eval7.Card(card) for card in board_cards]
    return eval7.handtype(eval7.evaluate(hand))

def StraightDrawCheck(game_state, round_state, active):
    """
    checks for straight draws, returns number of straight draws found.
    """