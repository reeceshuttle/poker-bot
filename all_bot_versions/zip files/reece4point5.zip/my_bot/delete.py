made_hand = 2


# --------------- strategy: --------------------
if made_hand in ["Straight Flush", "Quads", "Full House"]:
    "insert strategy here"
elif made_hand == "Flush":
    "insert flush strategy here"
elif made_hand == "Straight":
    "insert straight strategy here"
elif made_hand == "Trips":
    "insert trips strategy here"
elif made_hand == "Two Pair":
    "insert two pair strategy here"
elif made_hand == "Pair":
    "insert pair strategy here"
elif made_hand == "High Card":
    "insert high card strategy here"