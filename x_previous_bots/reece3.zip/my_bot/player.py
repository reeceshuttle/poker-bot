'''
Simple example pokerbot, written in Python.
'''
from skeleton.actions import FoldAction, CallAction, CheckAction, RaiseAction
from skeleton.states import GameState, TerminalState, RoundState
from skeleton.states import NUM_ROUNDS, STARTING_STACK, BIG_BLIND, SMALL_BLIND
from skeleton.bot import Bot
from skeleton.runner import parse_args, run_bot

import eval7
import random

class Player(Bot):
    '''
    A pokerbot.
    '''

    def __init__(self):
        '''
        Called when a new game starts. Called exactly once.

        Arguments:
        Nothing.

        Returns:
        Nothing.
        '''
        self.hand_num = 0

    def handle_new_round(self, game_state, round_state, active):
        '''
        Called when a new round starts. Called NUM_ROUNDS times.

        Arguments:
        game_state: the GameState object.
        round_state: the RoundState object.
        active: your player's index.

        Returns:
        Nothing.
        '''
        #my_bankroll = game_state.bankroll  # the total number of chips you've gained or lost from the beginning of the game to the start of this round
        #game_clock = game_state.game_clock  # the total number of seconds your bot has left to play this game
        #round_num = game_state.round_num  # the round number from 1 to NUM_ROUNDS
        #my_cards = round_state.hands[active]  # your cards
        self.big_blind = bool(active)  # True if you are the big blind
        self.hand_num+=1

    def handle_round_over(self, game_state, terminal_state, active):
        '''
        Called when a round ends. Called NUM_ROUNDS times.

        Arguments:
        game_state: the GameState object.
        terminal_state: the TerminalState object.
        active: your player's index.

        Returns:
        Nothing.
        '''
        #my_delta = terminal_state.deltas[active]  # your bankroll change from this round
        #previous_state = terminal_state.previous_state  # RoundState before payoffs
        #street = previous_state.street  # int of street representing when this round ended
        #my_cards = previous_state.hands[active]  # your cards
        #opp_cards = previous_state.hands[1-active]  # opponent's cards or [] if not revealed
        pass

    def ParseHoleCards(self, hole_cards):
        """
        hole_cards will look like this: ["Ac", "Ts"]
        """
        # dealing with suits
        if hole_cards[0][1] == hole_cards[1][1]: # suited
            last = 's'
        else: # unsuited
            last = 'u'

        # dealing with card ranks
        ranks = ["2", "3", "4", "5", "6", "7", "8", "9", "T", "J", "Q", "K", "A"]
        if ranks.index(hole_cards[0][0]) >= ranks.index(hole_cards[1][0]):
            first = f"{hole_cards[0][0]}{hole_cards[1][0]}"
        else:
            first = f"{hole_cards[1][0]}{hole_cards[0][0]}"
        return first + last
    

    def OpeningStrategy(self, game_state, round_state, active):
        """Used when on the button, always opens to 2.5x"""
        open_chart = {"AAu":1, "AKs":1, "AQs":1, "AJs":1, "ATs":1, "A9s":1, "A8s":1, "A7s":1, "A6s":1, "A5s":1, "A4s":1, "A3s":1, "A2s":1,
                      "AKu":1, "KKu":1, "KQs":1, "KJs":1, "KTs":1, "K9s":1, "K8s":1, "K7s":1, "K6s":1, "K5s":1, "K4s":1, "K3s":1, "K2s":1,
                      "AQu":1, "KQu":1, "QQu":1, "QJs":1, "QTs":1, "Q9s":1, "Q8s":1, "Q7s":1, "Q6s":1, "Q5s":1, "Q4s":1, "Q3s":1, "Q2s":1,
                      "AJu":1, "KJu":1, "QJu":1, "JJu":1, "JTs":1, "J9s":1, "J8s":1, "J7s":1, "J6s":1, "J5s":1, "J4s":1, "J3s":1, "J2s":1,
                      "ATu":1, "KTu":1, "QTu":1, "JTu":1, "TTu":1, "T9s":1, "T8s":1, "T7s":1, "T6s":1, "T5s":1, "T4s":1, "T3s":1, "T2s":1,
                      "A9u":1, "K9u":1, "Q9u":1, "J9u":1, "T9u":1, "99u":1, "98s":1, "97s":1, "96s":1, "95s":1, "94s":1, "93s":1, "92s":1,
                      "A8u":1, "K8u":1, "Q8u":1, "J8u":1, "T8u":1, "98u":1, "88u":1, "87s":1, "86s":1, "85s":1, "84s":1, "83s":1, "82s":1,
                      "A7u":1, "K7u":1, "Q7u":1, "J7u":1, "T7u":1, "97u":1, "87u":1, "77u":1, "76s":1, "75s":1, "74s":1, "73s":1, "72s":1,
                      "A6u":1, "K6u":1, "Q6u":1, "J6u":1, "T6u":1, "96u":1, "86u":1, "76u":1, "66u":1, "65s":1, "64s":1, "63s":1, "62s":1,
                      "A5u":1, "K5u":1, "Q5u":1, "J5u":1, "T5u":1, "95u":1, "85u":1, "75u":1, "65u":1, "55u":1, "54s":1, "53s":1, "52s":1,
                      "A4u":1, "K4u":1, "Q4u":1, "J4u":1, "T4u":1, "94u":0, "84u":0, "74u":0, "64u":0, "54u":1, "44u":1, "43s":1, "42s":1,
                      "A3u":1, "K3u":1, "Q3u":1, "J3u":1, "T3u":0, "93u":0, "83u":0, "73u":0, "63u":0, "53u":0, "43u":0, "33u":1, "32s":1,
                      "A2u":1, "K2u":1, "Q2u":1, "J2u":1, "T2u":0, "92u":0, "82u":0, "72u":0, "62u":0, "52u":0, "42u":0, "32u":0, "22u":1}
        
        # legal_actions = round_state.legal_actions()  # the actions you are allowed to take
        my_cards = round_state.hands[active]  # your cards
        print(f'my_cards:{my_cards}')
        print(f'parsed cards:{self.ParseHoleCards(my_cards)}')
        if open_chart[self.ParseHoleCards(my_cards)] == 1:
            return RaiseAction(5) # raise 2.5x
        else:
            return FoldAction()
    
    def DefenseStrategy(self, game_state, round_state, active):
        """
        Used when you are raised into.
        """
        under4x_defence_chart =  {"AAu":1, "AKs":1, "AQs":1, "AJs":1, "ATs":1, "A9s":1, "A8s":1, "A7s":1, "A6s":1, "A5s":1, "A4s":1, "A3s":1, "A2s":1,
                        "AKu":1, "KKu":1, "KQs":1, "KJs":1, "KTs":1, "K9s":1, "K8s":1, "K7s":1, "K6s":1, "K5s":1, "K4s":1, "K3s":1, "K2s":1,
                        "AQu":1, "KQu":1, "QQu":1, "QJs":1, "QTs":1, "Q9s":1, "Q8s":1, "Q7s":1, "Q6s":1, "Q5s":1, "Q4s":1, "Q3s":0, "Q2s":0,
                        "AJu":1, "KJu":1, "QJu":1, "JJu":1, "JTs":1, "J9s":1, "J8s":1, "J7s":0, "J6s":0, "J5s":0, "J4s":0, "J3s":0, "J2s":0,
                        "ATu":1, "KTu":1, "QTu":1, "JTu":1, "TTu":1, "T9s":1, "T8s":1, "T7s":1, "T6s":0, "T5s":0, "T4s":0, "T3s":0, "T2s":0,
                        "A9u":1, "K9u":1, "Q9u":1, "J9u":1, "T9u":1, "99u":1, "98s":1, "97s":1, "96s":0, "95s":0, "94s":0, "93s":0, "92s":0,
                        "A8u":1, "K8u":1, "Q8u":1, "J8u":0, "T8u":0, "98u":1, "88u":1, "87s":1, "86s":1, "85s":0, "84s":0, "83s":0, "82s":0,
                        "A7u":1, "K7u":1, "Q7u":0, "J7u":0, "T7u":0, "97u":0, "87u":0, "77u":1, "76s":1, "75s":0, "74s":0, "73s":0, "72s":0,
                        "A6u":1, "K6u":1, "Q6u":0, "J6u":0, "T6u":0, "96u":0, "86u":0, "76u":0, "66u":1, "65s":1, "64s":0, "63s":0, "62s":0,
                        "A5u":1, "K5u":1, "Q5u":0, "J5u":0, "T5u":0, "95u":0, "85u":0, "75u":0, "65u":0, "55u":1, "54s":1, "53s":0, "52s":0,
                        "A4u":1, "K4u":0, "Q4u":0, "J4u":0, "T4u":0, "94u":0, "84u":0, "74u":0, "64u":0, "54u":0, "44u":1, "43s":1, "42s":0,
                        "A3u":1, "K3u":0, "Q3u":0, "J3u":0, "T3u":0, "93u":0, "83u":0, "73u":0, "63u":0, "53u":0, "43u":0, "33u":1, "32s":1,
                        "A2u":1, "K2u":0, "Q2u":0, "J2u":0, "T2u":0, "92u":0, "82u":0, "72u":0, "62u":0, "52u":0, "42u":0, "32u":0, "22u":1}
        # update later
        my_cards = round_state.hands[active]  # your cards

        legal_actions = round_state.legal_actions()  # the actions you are allowed to take
        my_pip = round_state.pips[active]  # the number of chips you have contributed to the pot this round of betting
        opp_pip = round_state.pips[1-active]  # the number of chips your opponent has contributed to the pot this round of betting
        my_stack = round_state.stacks[active]  # the number of chips you have remaining
        opp_stack = round_state.stacks[1-active]  # the number of chips your opponent has remaining
        continue_cost = opp_pip - my_pip  # the number of chips needed to stay in the pot
        my_contribution = STARTING_STACK - my_stack  # the number of chips you have contributed to the pot
        opp_contribution = STARTING_STACK - opp_stack  # the number of chips your opponent has contributed to the pot
        if RaiseAction in legal_actions:
            min_raise, max_raise = round_state.raise_bounds()  # the smallest and largest numbers of chips for a legal bet/raise
            min_cost = min_raise - my_pip  # the cost of a minimum bet/raise
            max_cost = max_raise - my_pip  # the cost of a maximum bet/raise

        parsed_hand = self.ParseHoleCards(my_cards)
        if opp_pip < 8:
            if under4x_defence_chart[parsed_hand] == 1:
                return CallAction()
            else:
                return FoldAction()
        else:
            if parsed_hand[0] == parsed_hand[1]:
                if parsed_hand[0] not in ['2', '3', '4', '5', '6', '7', '8'] and RaiseAction in legal_actions:
                    return RaiseAction(max_raise)
                else: 
                    return CallAction()
            elif parsed_hand[:2] in ['AK', 'AQ', 'AJ', 'KQ', 'KJ']:
                if RaiseAction in legal_actions:
                    return RaiseAction(max_raise)
                else:
                    return CallAction()
            return FoldAction()
        

    def LimpStrategy(self, game_state, round_state, active):
        """
        Used when you are limped to.
        """
        limp_chart =  {"AAu":1, "AKs":1, "AQs":1, "AJs":1, "ATs":1, "A9s":1, "A8s":1, "A7s":1, "A6s":1, "A5s":1, "A4s":1, "A3s":1, "A2s":1,
                       "AKu":1, "KKu":1, "KQs":1, "KJs":1, "KTs":1, "K9s":1, "K8s":1, "K7s":1, "K6s":1, "K5s":1, "K4s":1, "K3s":1, "K2s":1,
                       "AQu":1, "KQu":1, "QQu":1, "QJs":1, "QTs":1, "Q9s":1, "Q8s":1, "Q7s":1, "Q6s":1, "Q5s":1, "Q4s":1, "Q3s":0, "Q2s":0,
                       "AJu":1, "KJu":1, "QJu":1, "JJu":1, "JTs":1, "J9s":1, "J8s":1, "J7s":0, "J6s":0, "J5s":0, "J4s":0, "J3s":0, "J2s":0,
                       "ATu":1, "KTu":1, "QTu":1, "JTu":1, "TTu":1, "T9s":1, "T8s":1, "T7s":1, "T6s":0, "T5s":0, "T4s":0, "T3s":0, "T2s":0,
                       "A9u":1, "K9u":1, "Q9u":1, "J9u":1, "T9u":1, "99u":1, "98s":1, "97s":1, "96s":0, "95s":0, "94s":0, "93s":0, "92s":0,
                       "A8u":1, "K8u":1, "Q8u":1, "J8u":0, "T8u":0, "98u":1, "88u":1, "87s":1, "86s":1, "85s":0, "84s":0, "83s":0, "82s":0,
                       "A7u":1, "K7u":1, "Q7u":0, "J7u":0, "T7u":0, "97u":0, "87u":0, "77u":1, "76s":1, "75s":0, "74s":0, "73s":0, "72s":0,
                       "A6u":1, "K6u":1, "Q6u":0, "J6u":0, "T6u":0, "96u":0, "86u":0, "76u":0, "66u":1, "65s":1, "64s":0, "63s":0, "62s":0,
                       "A5u":1, "K5u":1, "Q5u":0, "J5u":0, "T5u":0, "95u":0, "85u":0, "75u":0, "65u":0, "55u":1, "54s":1, "53s":0, "52s":0,
                       "A4u":1, "K4u":0, "Q4u":0, "J4u":0, "T4u":0, "94u":0, "84u":0, "74u":0, "64u":0, "54u":0, "44u":1, "43s":1, "42s":0,
                       "A3u":1, "K3u":0, "Q3u":0, "J3u":0, "T3u":0, "93u":0, "83u":0, "73u":0, "63u":0, "53u":0, "43u":0, "33u":1, "32s":1,
                       "A2u":1, "K2u":0, "Q2u":0, "J2u":0, "T2u":0, "92u":0, "82u":0, "72u":0, "62u":0, "52u":0, "42u":0, "32u":0, "22u":1}
        my_cards = round_state.hands[active]  # your cards
        if limp_chart[self.ParseHoleCards(my_cards)] == 1:
            return RaiseAction(random.randrange(6,8)) # raises to 6 or 7 chips with equal probability
        elif limp_chart[self.ParseHoleCards(my_cards)] == 0:
            return CheckAction()
    
    def EvalBoard(self, game_state, round_state, active):
        """
        evaluates board. Returns string saying what the board has. 
        """
        street = round_state.street  # int representing pre-flop, flop, turn, or river respectively
        board_cards = round_state.deck[:street]  # the board cards
        hand = [eval7.Card(card) for card in board_cards]
        return eval7.handtype(eval7.evaluate(hand))
    
    def StraightDrawCheck(self, game_state, round_state, active):
        """
        checks for straight draws, returns number of straight draws found.
        """
    


    def get_action(self, game_state, round_state, active):
        '''
        Where the magic happens - your code should implement this function.
        Called any time the engine needs an action from your bot.

        Arguments:
        game_state: the GameState object.
        round_state: the RoundState object.
        active: your player's index.

        Returns:
        Your action.
        '''
        legal_actions = round_state.legal_actions()  # the actions you are allowed to take
        street = round_state.street  # int representing pre-flop, flop, turn, or river respectively
        my_cards = round_state.hands[active]  # your cards
        board_cards = round_state.deck[:street]  # the board cards
        
        my_pip = round_state.pips[active]  # the number of chips you have contributed to the pot this round of betting
        opp_pip = round_state.pips[1-active]  # the number of chips your opponent has contributed to the pot this round of betting
        my_stack = round_state.stacks[active]  # the number of chips you have remaining
        opp_stack = round_state.stacks[1-active]  # the number of chips your opponent has remaining
        continue_cost = opp_pip - my_pip  # the number of chips needed to stay in the pot
        my_contribution = STARTING_STACK - my_stack  # the number of chips you have contributed to the pot
        opp_contribution = STARTING_STACK - opp_stack  # the number of chips your opponent has contributed to the pot
        if RaiseAction in legal_actions:
           min_raise, max_raise = round_state.raise_bounds()  # the smallest and largest numbers of chips for a legal bet/raise
           min_cost = min_raise - my_pip  # the cost of a minimum bet/raise
           max_cost = max_raise - my_pip  # the cost of a maximum bet/raise


        hand = [eval7.Card(card) for card in my_cards+board_cards]
        print(f'---------hand number {self.hand_num}------------')
        print(f'active:{active}')
        print(my_cards+board_cards)
        print(eval7.handtype(eval7.evaluate(hand)))
        print(f'board value:{self.EvalBoard(game_state, round_state, active)}')

        # print('test only:')
        # hand = [eval7.Card(card) for card in ['Ac', 'Kc', 'Qc', 'Jc']]
        # print(eval7.handtype(eval7.evaluate(hand)))
        made_hand = eval7.handtype(eval7.evaluate(hand))

        # pre-flop strategy
        print(f'street:{street}')
        if street == 0: # if we are pre-flop
            if my_pip == 1: # in small blind, implement opening ranges
                print('calling OpeningStrategy')
                return self.OpeningStrategy(game_state, round_state, active)
            elif my_pip == 2 and opp_pip == 2: # they limped, implement limping attack strategy
                return self.LimpStrategy(game_state, round_state, active)
            elif my_pip == 2 and opp_pip > 2: # they raised from the btn, implement defence strategy
                return self.DefenseStrategy(game_state, round_state, active)
            elif my_pip > 2 and opp_pip > 2:
                return CallAction()
        

        # post-flop strategy
        else:
            pot_size = 800 - my_stack - opp_stack
            print(f'pot size:{pot_size}')
            if my_contribution == 400:
                return CheckAction()

            elif my_pip == 0 and opp_pip == 0: # if you start or they checked to you
                if active == 0: # means we are on the btn, meaning we start betting round
                    # We want a strategy of betting with made hands and draws
                    if made_hand in ["Straight Flush", "Quads", "Full House"]:
                        # We are going for big value here.
                        return RaiseAction(min(max_raise, max(min_raise, int(pot_size-1))))
                    elif made_hand in ["Flush", "Straight", "Trips", "Two Pair"] and self.EvalBoard(game_state, round_state, active)!=made_hand:
                        # We are going for big value here.
                        return RaiseAction(min(max_raise, max(min_raise, int(pot_size-1))))
                    elif made_hand in ["Pair"] and self.EvalBoard(game_state, round_state, active) not in ["Pair"]:
                        return RaiseAction(min(max_raise, max(min_raise, int(0.5*pot_size))))
                        # Still value but less confident. 1/2 Pot
                    elif False: # "Have a good draw":
                        return RaiseAction(min(max_raise, max(min_raise, int(0.6*pot_size))))
                    else:
                        return CheckAction()

                elif active == 1: # means we are in the big blind, we have been checked to
                    # We want a strategy of betting with made hands and draws, but being wider than if leading
                    if made_hand in ["Straight Flush", "Quads", "Full House"]:
                        # We are going for big value here.
                        return RaiseAction(min(max_raise, max(min_raise, int(pot_size-1))))
                    elif made_hand in ["Flush", "Straight", "Trips", "Two Pair"] and self.EvalBoard(game_state, round_state, active)!=made_hand:
                        # We are going for big value here.
                        return RaiseAction(min(max_raise, max(min_raise, int(pot_size-1))))
                    elif made_hand in ["Pair"] and self.EvalBoard(game_state, round_state, active) not in ["Pair"]:
                        return RaiseAction(min(max_raise, max(min_raise, int(0.5*pot_size))))
                        # Still value but less confident. 1/2 Pot
                    elif False: # "Have a good draw":
                        return RaiseAction(min(max_raise, max(min_raise, int(0.6*pot_size))))
                    else:
                        if random.random()<0.5: return RaiseAction(min_raise)
                        else: return CheckAction()
            elif my_pip == 0 and opp_pip > 0: # They bet first, meaning they start or I checked to them
                if active == 0: # I checked to them, they bet
                    if made_hand in ["Straight Flush", "Quads", "Full House"]:
                        # We are going for big value here.
                        if RaiseAction in legal_actions: return RaiseAction(min(max_raise, max(min_raise, int(pot_size-1))))
                        else: return CallAction()
                    elif made_hand in ["Flush", "Straight", "Trips", "Two Pair"] and self.EvalBoard(game_state, round_state, active)!=made_hand:
                        # We are going for big value here.
                        if RaiseAction in legal_actions: return RaiseAction(min(max_raise, max(min_raise, int(pot_size-1))))
                        else: return CallAction()
                    elif made_hand in ["Pair"] and self.EvalBoard(game_state, round_state, active) not in ["Pair"]:
                        if random.random()<0.5: return CallAction()
                        else: return FoldAction()
                        # Still value but less confident. 1/2 Pot
                    elif False: # "Have a good draw":
                        return RaiseAction(min(max_raise, max(min_raise, int(0.6*pot_size))))
                    else:
                        return FoldAction()
                elif active == 1: # they bet into me
                    if made_hand in ["Straight Flush", "Quads", "Full House"]:
                        # We are going for big value here.
                        if RaiseAction in legal_actions: return RaiseAction(min(max_raise, max(min_raise, int(pot_size-1))))
                        else: return CallAction()
                    elif made_hand in ["Flush", "Straight", "Trips", "Two Pair"] and self.EvalBoard(game_state, round_state, active)!=made_hand:
                        # We are going for big value here.
                        if RaiseAction in legal_actions: return RaiseAction(min(max_raise, max(min_raise, int(pot_size-1))))
                        else: return CallAction()
                    elif made_hand in ["Pair"] and self.EvalBoard(game_state, round_state, active) not in ["Pair"]:
                        if random.random()<0.5: return CallAction()
                        else: return FoldAction()
                        # Still value but less confident. 1/2 Pot
                    elif False: # "Have a good draw":
                        return RaiseAction(min(max_raise, max(min_raise, int(0.6*pot_size))))
                    else:
                        return FoldAction()
                    
            elif my_pip > 0 and opp_pip > 0: # I bet and they raised
                return CallAction()
            return CheckAction()


            # elif CheckAction in legal_actions:  # check available
            #     pot_size = 800 - my_stack - opp_stack
            #     print(pot_size)
            #     if made_hand == 'Pair':
            #         return RaiseAction(min(max(min_cost+my_pip, int(0.35*pot_size)), max_cost))
            #     elif made_hand not in ['High Card']:
            #         return RaiseAction(min(max(min_cost+my_pip, int(0.5*pot_size)), max_cost))
            #     return CheckAction()
            # else: # we are bet into
            #     pot_size = my_contribution + opp_contribution
            #     if made_hand in ['Pair', 'High Card']:
            #         return FoldAction()
            #     elif made_hand not in ['Two Pair']:
            #         if opp_contribution == 400:
            #             return CallAction()
            #         elif RaiseAction in legal_actions:
            #             return RaiseAction(min(max(min_cost+my_pip, int(0.45*pot_size)), max_cost))
            #         else:
            #             return CallAction()
            #     else:
            #         return CallAction()
            # return CheckAction()

if __name__ == '__main__':
    run_bot(Player(), parse_args())
